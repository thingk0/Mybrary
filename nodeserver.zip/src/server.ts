import { AppDataSource } from "./data-source";
import { Image } from "./entity/Image";
import express, { Request, Response } from "express";
import multer, { FileFilterCallback } from "multer";
import path from "path";
import sharp from "sharp";
import fs, { unlinkSync } from "fs";
import { v4 as uuidv4 } from "uuid"; // 고유 이름을 주기 위함

const app = express();

AppDataSource.initialize()
  .then(() => {
    console.log("데이터베이스에 성공적으로 연결되었습니다.");
  })
  .catch((error) => {
    console.error("데이터베이스 연결 중 오류가 발생했습니다:", error);
  });

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // 임시 저장 디렉토리
    cb(null, "temp/");
  },
  filename: (req, file, cb) => {
    //const ext = path.extname(file.originalname).toLowerCase();
    const filename = `${Date.now()}-${uuidv4()}.png`;
    cb(null, filename); // 중복 이름 방지
  },
});

const fileFilter: (
  req: Request,
  file: Express.Multer.File,
  cb: FileFilterCallback
) => void = (req, file, cb) => {
  const allowedTypes = /jpeg|jpg|png/;
  const isAcceptedExtension = allowedTypes.test(
    path.extname(file.originalname).toLowerCase()
  );
  const isAcceptedMimeType = allowedTypes.test(file.mimetype);

  if (isAcceptedExtension && isAcceptedMimeType) {
    cb(null, true);
  } else {
    cb(new Error("Error: Only image files are allowed!"));
  }
};

const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 1024 * 1024 * 5, // 5MB
  },
});

app.post(
  "/upload-single",
  upload.single("image"),
  async (req: Request, res: Response) => {
    if (!req.file) {
      return res.status(400).send("No file uploaded.");
    }

    // 압축할 이미지의 최종 경로 설정
    // 우리는 압축할 이미지만 최종 저장할 것이므로, 어디서 요청했냐에 따라 저장될 디렉토리를 적절히 설정해야만 함
    const filename = `${Date.now()}-${uuidv4()}.jpeg`;
    const compressedImagePath = `images/${filename}`;

    const resimg = sharp(req.file.path).toFormat("png");
    console.log(resimg);

    //req.file.path는 업로드된 원본 이미지 파일의 저장 경로 (임시 저장 경로 = /temp)
    resimg
      .resize(800) // 너비 800px로 조정
      .toFormat("jpeg") // JPEG 형식으로 변환
      .jpeg({ quality: 80 }) // 품질 설정
      .toFile(compressedImagePath) // 압축된 이미지 저장 (미리 설정해준 압축본 저장 경로 = 진짜 저장경로)
      .then(async () => {
        // 데이터베이스에 이미지 메타데이터 저장
        const image = new Image();
        image.is_deleted = false;
        image.size = fs.statSync(compressedImagePath).size; // 압축 후 파일 크기
        image.format = "jpeg"; // 형식 설정
        image.image_name = filename;
        image.image_url = compressedImagePath; // 압축된 이미지 경로

        // req.file.path가 저장된 파일을 삭제 (임시 저장된 원본파일)
        // unlinkSync는 비동기로 처리한다는 뜻 (기다리지 않고 동시 수행)
        unlinkSync(req.file.path);
        console.log(req.file.path);

        try {
          const savedImage = await AppDataSource.getRepository(Image).save(
            image
          );

          res.json({
            message: "Image uploaded and saved successfully.",
            image: savedImage,
          });
        } catch (error) {
          console.error(error);
          res.status(500).send("Error saving image metadata.");
        }
      })
      .catch((error) => {
        console.error("Error processing image:", error);
        res.status(500).send("Error processing image.");
      });
  }
);

const port = 5000;
app.listen(port, () => console.log(`Server running on port ${port}`));
